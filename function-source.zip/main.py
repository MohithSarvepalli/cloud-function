import csv
from google.cloud.logging_v2.services.logging_service_v2 import LoggingServiceV2Client
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
import logging
from datetime import datetime, timedelta
from email import encoders

def send_log(request):
    # Set up logging
    logging.basicConfig(level=logging.INFO)

    # Replace with your project ID and log query
    PROJECT_ID = 'savvy-etching-384304'
    LOG_QUERY = 'logName="projects/savvy-etching-384304/logs/cloudfunctions.googleapis.com%2Fcloud-functions" timestamp>="{start_time}"'

    # Replace with your Gmail credentials and sender/recipient addresses
    EMAIL_USER = 'study111623@gmail.com'
    EMAIL_PASS = 'ffnjapfsebkoncie'
    EMAIL_TO = 'ms185834@ncr.com'
    EMAIL_SUBJECT = 'Log Explorer Query Results'

    # Replace with the name of the CSV file to write to
    CSV_FILE = '/tmp/log_entries.csv'

    client = LoggingServiceV2Client()

    # Calculate the start time for the log query (7 days ago)
    start_time = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%dT%H:%M:%S.%fZ')
    
    # Run the log query and write the results to a CSV file
    logging.info('Running log query...')
    with open(CSV_FILE, 'w', newline='') as csvfile:
        fieldnames = ['severity', 'trace', 'text_payload']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for entry in client.list_log_entries(resource_names=[f'projects/{PROJECT_ID}'], filter=LOG_QUERY.format(start_time=start_time)):
            writer.writerow({'severity': entry.severity, 'trace': entry.trace, 'text_payload': entry.text_payload})
    logging.info('Log query complete.')

    # Create the email message with the CSV file as an attachment
    logging.info('Creating email message...')
    msg = MIMEMultipart()
    msg['From'] = EMAIL_USER
    msg['To'] = EMAIL_TO
    msg['Subject'] = EMAIL_SUBJECT

    with open(CSV_FILE, 'rb') as f:
        attachment = MIMEBase('application', 'octet-stream')
        attachment.set_payload(f.read())
        encoders.encode_base64(attachment)
        attachment.add_header('Content-Disposition', f'attachment; filename={CSV_FILE}')
        msg.attach(attachment)

    logging.info('Email message created.')

    # Send the email using the Gmail SMTP server and log in using your email address and app password
    logging.info('Sending email...')
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(EMAIL_USER, EMAIL_PASS)
    server.sendmail(EMAIL_USER, [EMAIL_TO], msg.as_string())
    server.quit()
    logging.info('Email sent.')
    
    return f'Log entries written to {CSV_FILE} and sent via email'